# HỒNG AI VIDEO STUDIO PREMIUM 2.0 — Free Edition

## Tính năng có thể dùng miễn phí
- Tạo prompt đa thể loại, kịch bản và phân cảnh trong trình duyệt.
- Đọc thử văn bản bằng SpeechSynthesis/Web Speech API; liệt kê giọng máy hỗ trợ.
- Chọn ảnh và xem hiệu ứng chuyển động Ken Burns / zoom / pan / float / parallax giả lập.
- Dựng video slideshow từ ảnh và xuất WebM bằng MediaRecorder.
- Lưu / mở dữ liệu dự án JSON.
- Không cần API Key cho các chức năng trên.

## Giới hạn trung thực
- Giọng vùng miền, giới tính, độ tuổi tùy danh sách giọng của hệ điều hành/trình duyệt. Bộ chọn phong cách không biến một giọng người lớn thành giọng trẻ em thật.
- SpeechSynthesis là phát giọng thử, không tự xuất file âm thanh và không tự ghi âm thanh vào video trong bản này.
- Chuyển động ảnh là hiệu ứng camera/2.5D cục bộ, không phải AI sinh hành động/khuôn mặt mới.
- Xuất WebM; MP4 cần chuyển đổi hoặc thêm bộ mã hóa tương thích.
- Tạo video AI sinh cảnh thực sự cần nhà cung cấp mô hình; không có API miễn phí vô hạn được đảm bảo.

## GitHub Pages
1. Tạo repository `hong-ai-video-studio` (Public).
2. Upload `index.html` vào root.
3. Settings -> Pages -> Deploy from a branch.
4. Branch `main`, folder `/(root)`, Save.
5. Chờ deploy và mở URL Pages.

## Cloudflare Worker (tùy chọn)
1. Cloudflare Dashboard -> Workers & Pages -> Create -> Worker.
2. Tạo Worker, mở Edit code.
3. Dán nội dung `worker.js`, Deploy.
4. Trong `worker.js`, thay `YOUR-GITHUB-USERNAME` bằng username GitHub.
5. Mở ứng dụng -> Kết nối & triển khai -> nhập Worker URL -> Kiểm tra kết nối.

Worker mẫu chỉ có `/health` và endpoint `/api/video` trả 501 vì chưa có nhà cung cấp video được cấu hình. Đây là chủ ý để không giả lập chức năng hoặc lộ API key.
Nếu thêm API provider sau này: lưu key bằng Cloudflare Secrets (ví dụ `npx wrangler secret put PROVIDER_API_KEY`), gọi API từ Worker, xác thực origin và người dùng, áp dụng quota/rate limit, giới hạn kích thước upload và kiểm tra nội dung.

## Chạy thử trên máy tính
Có thể mở `index.html` trực tiếp bằng Chrome/Edge. Để tránh hạn chế một số API, chạy local server:
`python -m http.server 8000`
Sau đó mở `http://localhost:8000`.
