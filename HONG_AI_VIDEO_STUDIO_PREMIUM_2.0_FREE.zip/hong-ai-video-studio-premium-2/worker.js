// HỒNG AI VIDEO STUDIO PREMIUM 2.0 — Cloudflare Worker starter
// This is a health-check / secure-backend scaffold only.
// Do NOT put provider API keys in GitHub Pages or this file.
// Add secrets with: npx wrangler secret put PROVIDER_API_KEY
// Then implement a provider-specific endpoint using env.PROVIDER_API_KEY.

const ALLOWED_ORIGINS = [
  "https://YOUR-GITHUB-USERNAME.github.io",
  "http://localhost:8000",
  "http://127.0.0.1:8000"
];

function cors(origin) {
  const allowed = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    "Access-Control-Allow-Origin": allowed,
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Vary": "Origin"
  };
}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = request.headers.get("Origin") || "";
    const headers = cors(origin);
    if (request.method === "OPTIONS") return new Response(null, { headers });
    if (url.pathname === "/health" && request.method === "GET") {
      return Response.json({
        ok: true,
        app: "HONG AI VIDEO STUDIO PREMIUM 2.0",
        mode: "free-scaffold",
        message: "Worker is online. No paid AI provider is connected."
      }, { headers });
    }
    if (url.pathname === "/api/video" && request.method === "POST") {
      return Response.json({
        ok: false,
        code: "PROVIDER_NOT_CONFIGURED",
        message: "Chưa cấu hình nhà cung cấp video AI. Chế độ miễn phí cục bộ vẫn hoạt động trên GitHub Pages."
      }, { status: 501, headers });
    }
    return Response.json({ ok: false, error: "Not found" }, { status: 404, headers });
  }
};
